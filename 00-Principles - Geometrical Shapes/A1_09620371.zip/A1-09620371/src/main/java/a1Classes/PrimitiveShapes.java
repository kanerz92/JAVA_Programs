package a1Classes;

public abstract class PrimitiveShapes extends Shapes{//Abstract don't want to create object. 
	
	public abstract double getArea();
	public abstract String getName();
	

}
