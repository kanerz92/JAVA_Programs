package a1Classes;

public abstract class Shapes {//Don't want ability to create a shape object. Shapes is SuperClass
	
	public abstract double getArea();//Abstract methods to be implemented by all subclasses
	public abstract String getName();
	
}
